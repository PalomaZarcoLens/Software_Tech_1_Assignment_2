import cv2

image = cv2.imread('1_Gammar 2021_1_2021_06_03-13-19-23-856.PNG')
gray_image = cv2.cvtColor(image,
                          cv2.COLOR_BGR2GRAY)

result = cv2.imwrite('gray_image.png', gray_image)

print("Grayscale image saved successfully!")
print(f"Save successful: {result}")  # prints True if saved, False if failed